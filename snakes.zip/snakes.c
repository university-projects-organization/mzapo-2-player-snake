/*******************************************************************
  Project main function template for MicroZed based MZ_APO board
  designed by Petr Porazil at PiKRON

  change_me.c      - main file

  include your name there and license for distribution.

  Remove next text: This line should not appear in submitted
  work and project name should be change to match real application.
  If this text is there I want 10 points subtracted from final
  evaluation.

 *******************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <time.h>
#include <unistd.h>

#define STB_IMAGE_IMPLEMENTATION

#include "stb_library/stb_image.h"

#define STB_IMAGE_WRITE_IMPLEMENTATION

#include "stb_library/stb_image_write.h"

#include "mzapo_parlcd.h"
#include "mzapo_phys.h"
#include "mzapo_regs.h"
#include "serialize_lock.h"
#include "font_types.h"

#define HEIGHT 320
#define WIDTH 480
#define BLUEPRESSED 16777216
#define GREENPRESSED 16777216 * 2
#define REDPRESSED 16777216 * 4
#define BLUE 0
#define GREEN 1
#define RED 2

union pixel {
    struct {
        unsigned b: 5;
        unsigned g: 6;
        unsigned r: 5;
    };
    uint16_t d;
};

union pixel **allocateScreen(void) {
    union pixel **screen = (union pixel **) malloc(sizeof(union pixel *) * WIDTH);
    for (size_t i = 0; i < WIDTH; ++i) {
        screen[i] = (union pixel *) malloc(sizeof(union pixel) * HEIGHT);
    }
    return screen;
}

void freeScreen(union pixel **screen) {
    for (size_t i = 0; i < WIDTH; ++i) {
        free(screen[i]);
    }
    free(screen);
}

void setBackground(const unsigned char *image, union pixel **screen) {
    size_t i = 0;
    /*0x0000,
      0x0000,
      0x7e00,
      0x8100,
      0xa500,
      0x8100,
      0x8100,
      0xbd00,
      0x9900,
      0x8100,
      0x8100,
      0x7e00,
      0x0000,
      0x0000,
      0x0000,
      0x0000,*/
    for (size_t y = 0; y < HEIGHT; y++) {
        for (size_t x = 0; x < WIDTH; x++) {
            screen[x][y].r = image[i] >> 3;
            screen[x][y].g = image[i + 1] >> 2;
            screen[x][y].b = image[i + 2] >> 3;
            i += 3;
        }
    }
}

void setSelector(const unsigned char *selector, union pixel **screen, const size_t offsetY, const size_t offsetX) {
    size_t i = 0;
    for (size_t y = offsetY; y < (offsetY + 45); y++) {
        for (size_t x = offsetX; x < (offsetX + 45); x++) {
            if (selector[i + 3] == 255) {
                screen[x][y].r = selector[i] >> 3;
                screen[x][y].g = selector[i + 1] >> 2;
                screen[x][y].b = selector[i + 2] >> 3;
            }
            i += 4;
        }
    }
}

void loadScreen(union pixel **screen,  unsigned char *parlcd_reg_base) {
    for (size_t y = 0; y < HEIGHT; y++) {
        for (size_t x = 0; x < WIDTH; x++) {
            parlcd_write_data(parlcd_reg_base, screen[x][y].d);
        }
    }
}

void endGame(union pixel **screen, unsigned char *background, unsigned char *apple) {
    freeScreen(screen);
    free(background);
    free(apple);
    exit(0);
}

int8_t knobRotated(int32_t actualValue, int32_t *previousValue, int8_t knob, int8_t positions) {
    int32_t coef = 1;
    switch (knob) {
        case BLUE:
            coef = 4;
            break;
        case GREEN:
            coef = 1024;
            break;
        case RED:
            coef = 1;
            break;
    }
    printf("actualValue - %d previousValue - %d\n", actualValue, previousValue);
    int32_t difference = actualValue - *previousValue;
    printf("difference - %d coef - %d\n", difference, coef);
    int8_t step = (difference / coef) % positions;
    printf("step - %d  %d\n", step, difference / coef);
    *previousValue = actualValue;
    return step;
}

_Bool knobPressed(uint32_t actualKnob, uint32_t knobDigit, uint32_t knob) {
    return actualKnob - knobDigit == knob;
}

void settingsMenu(union pixel **screen, volatile void *spiled_reg_base, unsigned char *parlcd_reg_base){
    int width, height, channels;
    unsigned char *background = stbi_load("/tmp/nazar/resources/SettingsMenu/SettingsMenu.jpg", &width, &height, &channels, 0);
    unsigned char *pear = stbi_load("/tmp/nazar/resources/SettingsMenu/pear.png", &width, &height, &channels, 0);
    if (background == NULL || pear == NULL) {
        printf("Can not load image\n");
        exit(0);
    }

    uint16_t offsetY = 15;
    uint32_t volicBlue = *(volatile uint32_t *) (spiled_reg_base + SPILED_REG_KNOBS_8BIT_o) % 256;
    uint32_t previousG = *(volatile uint32_t *) (spiled_reg_base + SPILED_REG_KNOBS_8BIT_o) % 65536;
    uint32_t previousKnobs = *(volatile uint32_t *) (spiled_reg_base + SPILED_REG_KNOBS_8BIT_o);
    int8_t position = 0;

    while (1) {
        setBackground(background, screen);
        struct timespec loop_delay = {.tv_sec = 0, .tv_nsec = 200 * 1000 * 1000};


        uint32_t actualKnobs = *(volatile uint32_t *) (spiled_reg_base + SPILED_REG_KNOBS_8BIT_o);
        uint32_t actualB = actualKnobs % 256;
        uint32_t actualG = actualKnobs % 65536;
        uint32_t actualR = actualKnobs % BLUEPRESSED;


        int8_t step = knobRotated(actualG, &previousG, GREEN, 5);
        position = (position + step + 5) % 5;

        switch (position) {
            case 0:
                offsetY = 20;
                break;
            case 1:
                offsetY = 65;
                break;
            case 2:
                offsetY = 115;
                break;
            case 3:
                offsetY = 180;
                break;
            case 4:
                offsetY = 250;
                break;

        }

        setSelector(pear, screen, offsetY, 65);
        loadScreen(screen, parlcd_reg_base);

        if (knobPressed(actualKnobs, actualR, REDPRESSED)) {
            printf("Red break\n");
            break;
        }

        if (knobPressed(actualKnobs, actualR, GREENPRESSED)) {
            switch (position) {
                case 0:
                    printf("0 pressed\n");
                    break;
                case 1:
                    printf("1 pressed\n");
                    break;
                case 2:
                    printf("2 pressed\n");
                    break;
                case 3:
                    printf("3 pressed\n");
                    break;
                case 4:
                    printf("4 pressed\n");
                    break;
            }
        }
        clock_nanosleep(CLOCK_MONOTONIC, 0, &loop_delay, NULL);
    }
}

int main(int argc, char *argv[]) {
    volatile void *spiled_reg_base = map_phys_address(SPILED_REG_BASE_PHYS, SPILED_REG_SIZE, 0);

    unsigned char *parlcd_reg_base = map_phys_address(PARLCD_REG_BASE_PHYS, PARLCD_REG_SIZE, 0);
    parlcd_write_cmd(parlcd_reg_base, 0x2c);

    int width, height, channels;
    unsigned char *background = stbi_load("/tmp/nazar/resources/MainMenu/MainMenu.jpg", &width, &height, &channels, 0);
    unsigned char *apple = stbi_load("/tmp/nazar/resources/MainMenu/apple.png", &width, &height, &channels, 0);
    if (background == NULL || apple == NULL) {
        printf("Can not load image\n");
        exit(0);
    }

    union pixel **screen = allocateScreen();

    uint16_t offsetY = 15;
    uint32_t previousG = *(volatile uint32_t *) (spiled_reg_base + SPILED_REG_KNOBS_8BIT_o) % 65536;
    int8_t position = 0;
    while (1) {
        struct timespec loop_delay = {.tv_sec = 0, .tv_nsec = 200 * 1000 * 1000};
        setBackground(background, screen);

        uint32_t actualKnobs = *(volatile uint32_t *) (spiled_reg_base + SPILED_REG_KNOBS_8BIT_o);
        uint32_t actualG = actualKnobs % 65536;
        uint32_t actualR = actualKnobs % BLUEPRESSED;

        // if (actualG != previousG) {
        int8_t step = knobRotated(actualG, &previousG, GREEN, 4);
        position = (position + step + 4) % 4;
        switch (position) {
            case 0:
                offsetY = 10;
                break;
            case 1:
                offsetY = 90;
                break;
            case 2:
                offsetY = 180;
                break;
            case 3:
                offsetY = 260;
                break;
        }
        // }

        setSelector(apple, screen, offsetY, 30);
        loadScreen(screen, parlcd_reg_base);
        /*
        *(volatile uint32_t *) (spiled_reg_base + SPILED_REG_LED_LINE_o) = rgb_knobs_value;
        *(volatile uint32_t *) (spiled_reg_base + SPILED_REG_LED_RGB1_o) = rgb_knobs_value;
        *(volatile uint32_t *) (spiled_reg_base + SPILED_REG_LED_RGB2_o) = rgb_knobs_value;
        */

        if (knobPressed(actualKnobs, actualR, REDPRESSED)) {
            printf("Red break\n");
            break;
        }

        if (knobPressed(actualKnobs, actualR, GREENPRESSED)) {
            switch (position) {
                case 0:
                    printf("New Game pressed\n");
                    break;
                case 1:
                    printf("Records pressed\n");
                    break;
                case 2:
                    settingsMenu(screen, spiled_reg_base, parlcd_reg_base);
                    previousG = *(volatile uint32_t *) (spiled_reg_base + SPILED_REG_KNOBS_8BIT_o) % 65536;
                    break;
                default:
                    printf("Exit pressed\n");
                    endGame(screen, background, apple);
            }
        }
        clock_nanosleep(CLOCK_MONOTONIC, 0, &loop_delay, NULL);
    }
    endGame(screen, background, apple);
}
